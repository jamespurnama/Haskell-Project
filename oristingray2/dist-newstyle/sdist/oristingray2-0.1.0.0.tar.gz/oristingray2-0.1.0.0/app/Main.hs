-- James Purnama
--------------------
import System.IO
import System.Exit
import Control.Monad
import Data.List.Split

main = forever (mainMenu >> readChoice >>= mainMenuAction)
mainMenu = do 
            putStrLn "\ESC[1J"
            putStrLn "+-------------------------+"
            putStrLn "| MAIN MENU - ORISTINGRAY |"
            putStrLn "+-------------------------+"
            putStrLn "(0) Exit"
            putStrLn "(1) Stingray Fish Data"
            putStrLn "(2) handicraft craftsmen Data"
            putStrLn "(3) Stingray Leather Handicraft Data"
            putStrLn "(4) Originality Tracking of Handicraft"
            putStr   "Please Input Your Choice: " >> hFlush stdout

readChoice = hSetBuffering stdin NoBuffering >> hSetEcho stdin True >> getChar
mainMenuAction '1' = modul01
mainMenuAction '0' = do
                      putStrLn "\nGood By and Thank You"
                      exitSuccess
mainMenuAction _   = do 
                      hPutStrLn stderr "\nPlease input a number between 0 to 4"
                      hPutStrLn stderr "Press any key to continue" 
                      x <- getChar
                      putStrLn ""
data Fish = Fish {fishID :: String, fishName :: String, fishOrigin :: String} deriving Show
addFish :: String -> String -> String -> Fish
addFish x1 x2 x3 = Fish {fishID = x1, fishName = x2, fishOrigin = x3}
                                          
---------------------------------------------------------------
modul01 = forever (modul01Menu >> readChoice >>= modul01Action)
modul01Menu = do 
              putStrLn "\ESC[1J"
              putStrLn "+--------------------+"
              putStrLn "| STINGRAY FISH DATA |"
              putStrLn "+--------------------+"
              putStrLn "(0) Back to Main Menu"
              putStrLn "(1) Input Stingray Fish Data"
              putStrLn "(2) Delete Stingray Fish Data"
              putStrLn "(3) Print Stingray Fish Data"
              putStrLn "Please Input Your Choice: " >> hFlush stdout
modul01Action '0' = main
modul01Action '1' = modul0101_InputStingray
modul01Action '3' = modul0103_PrintStringray 
modul01Action _   = do 
                    hPutStrLn stderr "\nPlease input a number between 0 to 3"
                    hPutStrLn stderr "Press any key to continue" 
                    x <- getChar
                    putStrLn ""
  
modul0101_InputStingray = do
                          putStrLn "\ESC[1J"
                          putStrLn "*~~~~~~~~~~~~~~~~~~~~~~~~~~*"
                          putStrLn "{ INPUT STINGRAY FISH DATA }"
                          putStrLn "*~~~~~~~~~~~~~~~~~~~~~~~~~~*"
                          putStr "Fish ID       : " >> hFlush stdout
                          fishID <- getLine 
                          putStr "Fish Name     : " >> hFlush stdout
                          fishName <- getLine 
                          putStr "Fish Origin   : " >> hFlush stdout
                          fishOrigin <- getLine                           
                          -- let fishData = addFish fishID fishName fishOrigin
                          let fishTxt = fishID ++ "," ++ fishName ++ "," ++ fishOrigin ++ "\n"
                          appendFile "Fish.txt" fishTxt
                          putStrLn "The fish data has been saved, Thank You."
                          putStrLn "Press Any Key To Continue..."
                          -- print fishData
                          x <- getChar
                          putStrLn ""

modul0103_PrintStringray = do
        fishTxt <- readFile "Fish.txt"
        y <- splitOn "\n" fishTxt 
        putStrLn "\ESC[1J"
        putStrLn "*~~~~~~~~~~~~~~~~~~~~*"
        putStrLn "{ STINGRAY FISH DATA }"
        putStrLn "*~~~~~~~~~~~~~~~~~~~~*"
        putStrLn y
        putStrLn "Press Any Key To Continue..."
        x <- getChar
        putStrLn ""
--------------------
tampilMenuInput = do
--------------------
    hSetBuffering stdin NoBuffering >> hSetEcho stdin True
    putStrLn "\n\nSilahkan masukkan Nama Makanan yang akan di pesan ? "  
    iNamaMenu <- getLine
    -- putStrLn iNamaMenu
    putStrLn "\nJumlah yang ingin di beli? "
    iJmlMenu <- getLine
    -- putStrLn iJmlMenu
    putStrLn "\nHarga Satuan ? "
    iHargaSatuan <- getLine
    -- putStrLn iHargaSatuan
    -- let pesanan = addOrder iNamaMenu (read iJmlMenu) (read iHargaSatuan)
    putStrLn "\nPesanan Anda adalah: \n"
    -- print pesanan
